def sumar(num1, num2):
    print('El resultado de la suma es: ', num1 + num2)


def restar(num1, num2):
    print('El resultado de la restar es: ', num1 - num2)


def multiplicar(num1, num2):
    print('El resultado de multiplicar es: ', num1 * num2)


def dividir(num1, num2):
    print('El resultado de dividir es: ', num1 / num2)


def potencia(base, exponente):
    print('El resultado de la potencia es: ', base ** exponente)


def redondear(numero):
    print('El resultado de redondear es: ', round(numero))
